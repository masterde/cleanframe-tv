window.CleanFramePrivateFontIDs = ['geist', 'newsreader'];
